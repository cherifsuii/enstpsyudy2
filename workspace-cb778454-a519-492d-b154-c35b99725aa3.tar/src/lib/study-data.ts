export interface StudyMaterial {
  title: string;
  url: string;
  type: 'course' | 'exercise' | 'exam' | 'td' | 'resume' | 'book' | 'other';
  language: 'french' | 'english' | 'both';
}

export interface Subject {
  name: string;
  materials: StudyMaterial[];
}

export interface Semester {
  name: string;
  subjects: Subject[];
}

export interface Year {
  name: string;
  semesters: Semester[];
}

export interface Program {
  name: string;
  years: Year[];
}

// Preparatory Cycle Data
export const preparatoryCycle: Program = {
  name: "Cycle Préparatoire",
  years: [
    {
      name: "1ère Année",
      semesters: [
        {
          name: "Semestre 1",
          subjects: [
            {
              name: "Algèbre 1",
              materials: [
                { title: "Interrogation 4", url: "https://drive.google.com/file/d/1oQZ_2NoB8QwH4Ui5qTKY6j8rngCipumT/view?usp=drive_link", type: "exam", language: "french" },
                { title: "Correction Interro 4", url: "https://drive.google.com/file/d/1dsPN3UDDSWeWKMxFgZDS--WBQG_uDlU9/view?usp=drive_link", type: "other", language: "french" },
                { title: "Interrogation 3 avec correction", url: "https://drive.google.com/file/d/12PDwJfLdO5OMwnIYQIU2GClbtL2DibUu/view?usp=drive_link", type: "exam", language: "french" },
                { title: "Interrogation 2 avec correction", url: "https://drive.google.com/file/d/1cySBu3er3SQSsHzQVZAYz7Xv440v7f7m/view?usp=drive_link", type: "exam", language: "french" },
                { title: "Interrogation 1", url: "https://drive.google.com/file/d/1bB7kjg-u0lT25FsSL1uQ9LTGlsFZ696Y/view?usp=drive_link", type: "exam", language: "french" },
                { title: "Correction Interro 1", url: "https://drive.google.com/file/d/1oThF_QmAP6dgb5aWnluujbft19M1Qnc_/view?usp=drive_link", type: "other", language: "french" },
                { title: "Chapitre 1", url: "https://drive.google.com/file/d/1dsPN3UDDSWeWKMxFgZDS--WBQG_uDlU9/view?usp=drive_link", type: "course", language: "french" },
                { title: "Chapitre 2", url: "https://drive.google.com/file/d/1dsPN3UDDSWeWKMxFgZDS--WBQG_uDlU9/view?usp=drive_link", type: "course", language: "french" },
                { title: "Chapitre 3", url: "https://drive.google.com/file/d/1dsPN3UDDSWeWKMxFgZDS--WBQG_uDlU9/view?usp=drive_link", type: "course", language: "french" },
                { title: "Chapitre 4", url: "https://drive.google.com/file/d/1dsPN3UDDSWeWKMxFgZDS--WBQG_uDlU9/view?usp=drive_link", type: "course", language: "french" },
                { title: "Tous les chapitres en anglais", url: "https://drive.google.com/drive/folders/1k27NTpAwY1ivkashFYwoYfXPQ9WED93X?usp=drive_link", type: "course", language: "english" },
                { title: "Examens en français", url: "https://drive.google.com/file/d/1p83jbgXs7d0KNWoBMRIsbdzmNtQLrUCf/view?usp=drive_link", type: "exam", language: "french" },
                { title: "Examens en anglais", url: "https://drive.google.com/file/d/1p83jbgXs7d0KNWoBMRIsbdzmNtQLrUCf/view?usp=drive_link", type: "exam", language: "english" }
              ]
            },
            {
              name: "Analyse 1",
              materials: [
                { title: "Chapitre 1", url: "https://drive.google.com/file/d/1p83jbgXs7d0KNWoBMRIsbdzmNtQLrUCf/view?usp=drive_link", type: "course", language: "french" },
                { title: "Chapitre 2", url: "https://drive.google.com/file/d/1p83jbgXs7d0KNWoBMRIsbdzmNtQLrUCf/view?usp=drive_link", type: "course", language: "french" },
                { title: "Chapitre 4", url: "https://drive.google.com/file/d/1p83jbgXs7d0KNWoBMRIsbdzmNtQLrUCf/view?usp=drive_link", type: "course", language: "french" },
                { title: "Chapitre 5", url: "https://drive.google.com/file/d/1p83jbgXs7d0KNWoBMRIsbdzmNtQLrUCf/view?usp=drive_link", type: "course", language: "french" },
                { title: "Cours en anglais", url: "https://drive.google.com/file/d/1p83jbgXs7d0KNWoBMRIsbdzmNtQLrUCf/view?usp=drive_link", type: "course", language: "english" },
                { title: "Série TD 1", url: "https://drive.google.com/open?id=1-pZg2YaS6LEfl1MQOFbfP-UFx9OoUNfq&usp=drive_copy", type: "td", language: "french" },
                { title: "Série TD 2", url: "https://drive.google.com/open?id=1n3C2M2AdgQ7TfhXBz-vaAJ-JqTduwGN7&usp=drive_copy", type: "td", language: "french" },
                { title: "Série TD 3", url: "https://drive.google.com/open?id=1MCs8Fd6auliRCb3DKbbbhWq-9ukWLk9t&usp=drive_copy", type: "td", language: "french" },
                { title: "Série TD 4", url: "https://drive.google.com/open?id=18QLGbP1Tt8F1BS0D8do808myK9-xgiHk&usp=drive_copy", type: "td", language: "french" },
                { title: "Série TD 5", url: "https://drive.google.com/open?id=1-buUT2nhtJteX__cdfxn5m527VPIQTCx&usp=drive_copy", type: "td", language: "french" },
                { title: "Série TD 6", url: "https://drive.google.com/open?id=1xDpG8aGYMF1EdYb2giLeh56t5av303V4&usp=drive_copy", type: "td", language: "french" },
                { title: "Examen 1", url: "https://drive.google.com/open?id=18YG0Xo8pm-kAVPpgPfsDWZnxVVbbZ8u_&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 2", url: "https://drive.google.com/open?id=1FCaN5XSVH-xQf-Dc3dalUzlElknoF3Sm&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 3", url: "https://drive.google.com/open?id=1sDcoV2X70gyUmZ0gZmwioqMREZkzgtyJ&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 4", url: "https://drive.google.com/open?id=1jU2sLYf9GhmcBVdSg3a70qkO8-pXJJ9q&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 5", url: "https://drive.google.com/open?id=1NAQdeWotcrdI-YafmYo5TE3JpGC79YsP&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 6", url: "https://drive.google.com/open?id=1DP7bfb1sF0R9BJ1TZxUQykExZ9_dZLyt&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 7", url: "https://drive.google.com/open?id=1A0uptYSUxLwPd9CNkCK9z-DfOX5BLVki&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 8", url: "https://drive.google.com/open?id=13MuoHzeGYMEUxc3I2mH5YsYvmBJAty3Y&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 9", url: "https://drive.google.com/open?id=1v2Jo7qrT7kxFirD4hvYsfeTeSQNYDpgF&usp=drive_copy", type: "exam", language: "french" }
              ]
            },
            {
              name: "Physique 1",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=1gg3N6GJaMsfzmycbBWc1C_xNh9w6B9IY&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=1w8NU5zzsDyGJa4hEXlF_HV1TtrNPOWq8&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3", url: "https://drive.google.com/open?id=1iJ6K6kK8Oz-Jmoj5Pm3MzN0vF1nuPMqh&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 4", url: "https://drive.google.com/open?id=1wkkw3GFLZ3KFToyQ8v0tX_VwlfRBEBqF&usp=drive_copy", type: "course", language: "french" },
                { title: "Lexique important", url: "https://drive.google.com/open?id=1lDLOjiMm6N5lW4DGHM6IbDhUtB2A8T8E&usp=drive_copy", type: "other", language: "french" },
                { title: "Série TD 1 (anglais)", url: "https://drive.google.com/open?id=1IaLzVn6aDMpZL_Xq_X9hzVKIU8-tNdSk&usp=drive_copy", type: "td", language: "english" },
                { title: "Série TD 2 (anglais)", url: "https://drive.google.com/open?id=1ZBLrXskm96QppO9QjyavtD_LOVZEPRoe&usp=drive_copy", type: "td", language: "english" },
                { title: "Série TD 3 (anglais)", url: "https://drive.google.com/open?id=1E9W8TUDd4mhgyYf74fgoRaOHLXVwsg1h&usp=drive_copy", type: "td", language: "english" },
                { title: "Série TD 4 (anglais)", url: "https://drive.google.com/open?id=1_N42mux0DsTvpL-V8eAF_hx60ExtZc5W&usp=drive_copy", type: "td", language: "english" },
                { title: "Solutions TD 1 (anglais)", url: "https://drive.google.com/open?id=1NlwoyBZZkoQN91dUEuQDx4PhW-cW6Hi2&usp=drive_copy", type: "other", language: "english" },
                { title: "Solutions TD 2 (anglais)", url: "https://drive.google.com/open?id=1jlsX6MdROMvPCu8-dtv1XHKwX7_1cy5S&usp=drive_copy", type: "other", language: "english" },
                { title: "Solutions TD 3 (anglais)", url: "https://drive.google.com/open?id=19a9kFkSEcJvPl8AVxIFobJ4sg8utWkSK&usp=drive_copy", type: "other", language: "english" },
                { title: "Solutions TD 4 (anglais)", url: "https://drive.google.com/open?id=154HOK4GsAMiUWyu2AJZ1gJlYRs4c8k6r&usp=drive_copy", type: "other", language: "english" },
                { title: "Examen 1 (anglais)", url: "https://drive.google.com/open?id=1UZ84wd3G-I0icVI5UaEgW5XORfhZKoAp&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 2 (anglais)", url: "https://drive.google.com/open?id=19B9zTOzCp32T54nQwXPJvVX9vLtn-cIk&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 3 (anglais)", url: "https://drive.google.com/open?id=1qyeKe5Xt6_MiZkMmbAzDYfFXGl-khAQh&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 4 (anglais)", url: "https://drive.google.com/open?id=1VgjRxl4pYOJqTJXwhBenXGISfmGbT924&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 5 (anglais)", url: "https://drive.google.com/open?id=1H5_yFOGyhjqma4YO6O68qleveHdLcK6_&usp=drive_copy", type: "exam", language: "english" }
              ]
            },
            {
              name: "Chimie 1",
              materials: [
                { title: "Cours 1 (anglais)", url: "https://drive.google.com/open?id=1wo68ow2R-bShpD3dOKzdoX8WE1JdYiJD&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 2 (anglais)", url: "https://drive.google.com/open?id=1XXJlUuHfYntbKE101mk8I3WXajDu1IJu&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 3 (anglais)", url: "https://drive.google.com/open?id=15-2RPJZuq8k4bMtg1sJPvaQum1jJn3ca&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 4 (anglais)", url: "https://drive.google.com/open?id=1QCzEl7brB-x739ZJdy0KVUQ9T-LgBHCh&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 5 (anglais)", url: "https://drive.google.com/open?id=1jTspNm4SfnkVj455fP3L0h26WFcaqdqe&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 6 (anglais)", url: "https://drive.google.com/open?id=1AT0a0-xZFmJBjqkkbRUYcSo8TgHguwSL&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 7 (anglais)", url: "https://drive.google.com/open?id=1Tw3iCwSeO_BOagZyhNqM8pLk6EDna-uP&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 8 (anglais)", url: "https://drive.google.com/open?id=16YsG3ZeMDOO5hDc7ln9auxb23eDSChKi&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 9 (anglais)", url: "https://drive.google.com/open?id=13y8RAlQVXu4gAtgGouJOyeZzYRWbEAmh&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 10 (anglais)", url: "https://drive.google.com/open?id=1YgTjIvZKai91QK0rWds7xayjN6d3RXAG&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 1 (français)", url: "https://drive.google.com/open?id=1gREiRUWzQO6xCAAPSe6MVLE8RdOfshYp&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2 (français)", url: "https://drive.google.com/open?id=128rxMYCvdMZiwNbDp_FdbAWgBBGMM_5Z&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3 (français)", url: "https://drive.google.com/open?id=1s12_8-Am6MGqbkyFaK1rqL3bFpmLgNbN&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 4 (français)", url: "https://drive.google.com/open?id=12xGLvd4HEVs042FU6mqweltJBbqR4IEJ&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 5 (français)", url: "https://drive.google.com/open?id=1uMhknicQzFGKJaFBCA63zfx5GsEMYLRg&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 6 (français)", url: "https://drive.google.com/open?id=1EM9ZTexsFsDA3_PBjKeN_I07Hlb2xaLR&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 7 (français)", url: "https://drive.google.com/open?id=1cW2LJAV0Xa_EzSPWNUDMalB8a1WrAUVR&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 8 (français)", url: "https://drive.google.com/open?id=1JzLN7yIIZd2tF3fJlxDNVhCIkXfbnoFc&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 9 (français)", url: "https://drive.google.com/open?id=1CVKfM6m3PURo2g3hWV1FfVphfAgsTVOG&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 10 (français)", url: "https://drive.google.com/open?id=1Sf2jcclL7xp-qWiCkTUx-zSvozY6vcFO&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 11 (français)", url: "https://drive.google.com/open?id=1G6E4SSxF6hcVMIyQc3Ra439cJSjg4Z88&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 12 (français)", url: "https://drive.google.com/open?id=1eYBQev2ZPrpDbcy8a2iafrJitjJUdHsg&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 13 (français)", url: "https://drive.google.com/open?id=1AXR9amzos_GCt84Do_Q0-rTgpvf2ZzPi&usp=drive_copy", type: "course", language: "french" },
                { title: "TD 1 (anglais)", url: "https://drive.google.com/open?id=1BxEUImbPAU3rgBrbzwQY8a6jeieD7wwF&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 2 (anglais)", url: "https://drive.google.com/open?id=19qzbF9CdnvZEmu6VWkCq-oftcS3M62TQ&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 3 (anglais)", url: "https://drive.google.com/open?id=1EnJHWHpUT_oPfUkAnhm___cdPnYEKT41&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 4 (anglais)", url: "https://drive.google.com/open?id=1s0PBz0oiqKjxPfxobc7fTqFBYyp7lVZ7&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 5 (anglais)", url: "https://drive.google.com/open?id=1iJXbkubrYgrxsGLLeSvzDULkBVUrbDxn&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 6 (anglais)", url: "https://drive.google.com/open?id=1xbgnSRpYH_FU1cn1BWin7DEDaPx4OMw8&usp=drive_copy", type: "td", language: "english" },
                { title: "Solutions TD 1 (anglais)", url: "https://drive.google.com/open?id=1kNF6FOHlm8CHnwjUbLj96S4YBIWoQ_Mh&usp=drive_copy", type: "other", language: "english" },
                { title: "Solutions TD 2 (anglais)", url: "https://drive.google.com/open?id=1X9dSBfIzoh_UbwhOP8Dg3WmVBw5eyzs2&usp=drive_copy", type: "other", language: "english" },
                { title: "Solutions TD 3 (anglais)", url: "https://drive.google.com/open?id=1Lw9NIVHgj_sKevGO0VCe_O5MNOkPIIPs&usp=drive_copy", type: "other", language: "english" },
                { title: "Solutions TD 4 (anglais)", url: "https://drive.google.com/open?id=1fygqJRmcukfFyK4pfkCpVhGHtZ0K-Yyj&usp=drive_copy", type: "other", language: "english" },
                { title: "Solutions TD 5 (anglais)", url: "https://drive.google.com/open?id=18oYDl-kyj77qSsKeVbezIzPk5-X2nT4P&usp=drive_copy", type: "other", language: "english" },
                { title: "Solutions TD 6 (anglais)", url: "https://drive.google.com/open?id=1q4FiAETt553RKcPNh8vLWdxhEGGttIXg&usp=drive_copy", type: "other", language: "english" },
                { title: "TD 1 (français)", url: "https://drive.google.com/open?id=1Xm_bBC-66XTVwEUClGNUi6pRK8L7HsAb&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 2 (français)", url: "https://drive.google.com/open?id=1QcBCQk3F_gAiwTjXOD0hZ7DbkS_amt9J&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 3 (français)", url: "https://drive.google.com/open?id=1nc0YMYj79O14HyQS6VnK_9htuhM07KQ9&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 4 (français)", url: "https://drive.google.com/open?id=1dzHPIbjLF2EoWCzF5qOWw4dGVn5hNE_X&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 5 (français)", url: "https://drive.google.com/open?id=1aqPnHKKKrvH7a2105lAk741Lg790CxrP&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 6 (français)", url: "https://drive.google.com/open?id=1r7J2FQExwcrQoEbKiLnBIKZ71enuqtMF&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 7 (français)", url: "https://drive.google.com/open?id=1zlQG1tyuXPR-elr9W9rcaeBCpbryX3LY&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 8 (français)", url: "https://drive.google.com/open?id=1kEWhhxtHyRg3pUKZ7gS8QZJ508hzFkuW&usp=drive_copy", type: "td", language: "french" },
                { title: "Examen 1 (anglais)", url: "https://drive.google.com/open?id=18Gh82Cb3oVKr0gtMLOPNfuY3j7rgR7Ka&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 2 (anglais)", url: "https://drive.google.com/open?id=1njKy9Ud8VcpEk31w173w15pjLN6ueziP&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 3 (anglais)", url: "https://drive.google.com/open?id=1x9a7AuNtGkd3Xadol6jpDTuUE0_XLnsU&usp=drive_copy", type: "exam", language: "english" }
              ]
            },
            {
              name: "Économie 1",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=1iA34R0k1NsGZl8bMmiwKdNSl4cu2dcXN&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=1fImkyrOhsIFxhv3QbMQ3-pIRyM3cTVHS&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3", url: "https://drive.google.com/open?id=16O0RWm8RsgYU8Yha6f6FSUlI4-hmOuXF&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours en anglais", url: "https://drive.google.com/open?id=1iA34R0k1NsGZl8bMmiwKdNSl4cu2dcXN&usp=drive_copy", type: "course", language: "english" }
              ]
            },
            {
              name: "Dessin Technique 1",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=1MylbIh4-N696EgAEC2hmhm0Lt2TS7CPi&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=1QW_bgImJuAwa8rWt7-8bG7F91SDu-ov2&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3", url: "https://drive.google.com/open?id=1PntGxE2It0TcP27VcP5b_hS3bbLrDICZ&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 4", url: "https://drive.google.com/open?id=136h28MOwrtFZJnwutbOhbu-skLHJd11U&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 5", url: "https://drive.google.com/open?id=1_JUcgbSDHgzfOrisULs6LRtA951Z706l&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 6", url: "https://drive.google.com/open?id=1kN46S0rPJ_fSCOGqEuu7TsSU3ePGir_l&usp=drive_copy", type: "course", language: "french" }
              ]
            },
            {
              name: "Français 1",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=1NU3VfDdFDeQAiVh63RXRhMgYEq2Pr2Qp&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=1C4r6U0NDybk-3zlLghwulG26Xk84gg-9&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3", url: "https://drive.google.com/open?id=1zRyMlB1H5NN5-nFqk1csYXM--AToW2qw&usp=drive_copy", type: "course", language: "french" }
              ]
            },
            {
              name: "Informatique 1",
              materials: [
                { title: "Cours 1 (français)", url: "https://drive.google.com/open?id=1zBvi9NPcOv_CMNq_CHxYbdwSKckmJZIM&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2 (français)", url: "https://drive.google.com/open?id=1E_zPzCejld33XaCkiR1aKoGhwPSNxXVb&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 1 (anglais)", url: "https://drive.google.com/open?id=1NWXjHQtdqkK5ZXo3ddIiaXaJyR1bWttw&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 2 (anglais)", url: "https://drive.google.com/open?id=1TJxlJrKH_pMhF1DDmD8xXnd73cOmB0K5&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 3 (anglais)", url: "https://drive.google.com/open?id=19PS3rv3MeJcTG0P8t_PafTT4Ew1nEp9n&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 4 (anglais)", url: "https://drive.google.com/open?id=1SwIlRcX8ZkpURen0eu1wPCQ90UZhIF8G&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 5 (anglais)", url: "https://drive.google.com/open?id=1klQA2E5Xivcb8v1KEtV6jSX83aIfFTSu&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 6 (anglais)", url: "https://drive.google.com/open?id=17St9hee6Bqp-TH8wi3T6b-vpLeyCrV76&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 7 (anglais)", url: "https://drive.google.com/open?id=17w2f5pWd2FvNrtBbpiHQRl8_7dpTMSa9&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 8 (anglais)", url: "https://drive.google.com/open?id=1lVOfEgiiZIlnQnwmB_xcW1A9OnutSTOG&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 9 (anglais)", url: "https://drive.google.com/open?id=1yJE6o_wutNTweWnY8JcxNrSKDaeZq7wR&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 10 (anglais)", url: "https://drive.google.com/open?id=1lzeQQ8DzgtAWJyDkqhCsz4PPCqGUnmfx&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 11 (anglais)", url: "https://drive.google.com/open?id=1CmlzTKUZVwawhq0S9YU1WCpB_EmsIIaz&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 12 (anglais)", url: "https://drive.google.com/open?id=1BXfdW87FD2Ufe2VR11BWp7nF-W-mzimE&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 13 (anglais)", url: "https://drive.google.com/open?id=1QnaybHRTRDGmPvUuFBNpPBa9NErQ4Sw8&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 14 (anglais)", url: "https://drive.google.com/open?id=123w15kcd588_N-YwT72EJzExJQnN1iqF&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 15 (anglais)", url: "https://drive.google.com/open?id=1lK4Cyr20-ojttk_nHOSGAM47-b_uQog2&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 16 (anglais)", url: "https://drive.google.com/open?id=1E_Ty6L5iHzUHtUXPyB0pMn9qy9aJ6zM3&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 17 (anglais)", url: "https://drive.google.com/open?id=13p2YM-6Ua26KGOk3M-zF2dTuqm3DV-C4&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 18 (anglais)", url: "https://drive.google.com/open?id=1yHKh12UHM-RujO4RF4rHXPO8SewirnVZ&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 19 (anglais)", url: "https://drive.google.com/open?id=1ejzWurnUbooWGQ4XQ5y-5fG42lh0Y6lw&usp=drive_copy", type: "course", language: "english" },
                { title: "TD 1", url: "https://drive.google.com/open?id=1JaLmR2ZoodwEXFVgUafD2I5xMmo3kt3X&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 2", url: "https://drive.google.com/open?id=15kkHIkO_Gbr50p_kZuJMWyJRiJOh8DRH&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 3", url: "https://drive.google.com/open?id=1BM3lnyQf4mK3mUlpPFV0hJChZUj1y5Xp&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 4", url: "https://drive.google.com/open?id=16AHkEVSQB07YJMKGRGjIKKEdz7dmLboz&usp=drive_copy", type: "td", language: "french" }
              ]
            },
            {
              name: "Human Engineering 1",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=1Yd4gzS7KNeC4eb7lvPlQSJEyR-10UDYw&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=1w2znhVQMgJCY_6TShiiJ5b6ZNo9ehQmW&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3", url: "https://drive.google.com/open?id=1K37oa4yDvGRFxOzX4oUu76DAkq9WPNgN&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 4", url: "https://drive.google.com/open?id=17vsCEZ9_PZJs5KkPPauZ71DgQY_4iKLv&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 5", url: "https://drive.google.com/open?id=13H6MjRlrDprwzF9__8vehHAOfLlr5WE6&usp=drive_copy", type: "course", language: "french" }
              ]
            },
            {
              name: "Statistics 1",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=1H3NHKKw7rBt8IAb5rcSFctKUuyR81pyh&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=1f2Jt43sxbBOPr-kyv1IFVIi0iobKEDHd&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3", url: "https://drive.google.com/open?id=1dQQ6H7H9figaNQOF2bhb1oCcNg_YBXtI&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 4", url: "https://drive.google.com/open?id=1bi6fT-Ydvil26aHlsI0CKjgjWjS8rJYY&usp=drive_copy", type: "course", language: "french" },
                { title: "Examen 1 (anglais)", url: "https://drive.google.com/open?id=1vlUVqsbzxq8dBx9D9tV1qB9B87ufXbgE&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 2 (anglais)", url: "https://drive.google.com/open?id=1g9V900QMRYd7sURVCNcI04xXAQsDbZAn&usp=drive_copy", type: "exam", language: "english" }
              ]
            }
          ]
        },
        {
          name: "Semestre 2",
          subjects: [
            {
              name: "Algèbre 2",
              materials: [
                { title: "Cours 1 (anglais)", url: "https://drive.google.com/open?id=1toDaW_GXlIcU9JTBsRKN3bFvS0vssFBB&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 2 (anglais)", url: "https://drive.google.com/open?id=1iX0RpUg6BYL_ZJVtOTvkFRh7FD1ujKNt&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 3 (anglais)", url: "https://drive.google.com/open?id=1yBqbgoGFjLy7Nngo3wXlhKXCyrEMtZTO&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 4 (anglais)", url: "https://drive.google.com/open?id=1yFiK9JUGYiQU4_NxolDwSPKYa8ew8vvb&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 5 (anglais)", url: "https://drive.google.com/open?id=1y3k_wM4n7GiFZpK4Qp_G-KVOnVVAh8lf&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 6 (anglais)", url: "https://drive.google.com/open?id=1qkpQotlp1cOFInOmHamiaNVzJ9hEQJXF&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 7 (anglais)", url: "https://drive.google.com/open?id=1-vld9PcVh4waK4DuBE64pVdG5T_n1YHF&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 1 (anglais 2)", url: "https://drive.google.com/open?id=1mnEWheCjf5jHJn5a08B7ppeZsjazPm2W&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 2 (anglais 2)", url: "https://drive.google.com/open?id=1p7JY6yZnVlaM6nJtt5x5n-aKEG3_aQ77&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 3 (anglais 2)", url: "https://drive.google.com/open?id=1eV4ZQldeW49LdgkyRChjio0LXQf8RBV6&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 4 (anglais 2)", url: "https://drive.google.com/open?id=1LPrq2CWQ0m-eDpnQHaDBCkvcsRtPkHhD&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 5 (anglais 2)", url: "https://drive.google.com/open?id=1aFN6IrgFJDz12L8f-fznUACbu5Xe_lKK&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 6 (anglais 2)", url: "https://drive.google.com/open?id=1qKJLABvyw2HeuF0m4-864GQGNTXoptpo&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 7 (anglais 2)", url: "https://drive.google.com/open?id=1CbzICukwirvbl0eiruKlL5i00GgMB16k&usp=drive_copy", type: "course", language: "english" },
                { title: "TD et Exercices (français)", url: "https://drive.google.com/open?id=1mC9P6VfLeentC0wBiIHBCX_E31Drxbo6&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 2 (français)", url: "https://drive.google.com/open?id=14jVrJZiFymP_POLFiQEHGKl1IV2nGers&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 3 (français)", url: "https://drive.google.com/open?id=1c0NG3Lwj2nNdLYyTSyfPcYv4CQ3AjJCp&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 4 (français)", url: "https://drive.google.com/open?id=1sIqEcPTGYfxM3p29_Cr7CdyCqoNiweq8&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 5 (français)", url: "https://drive.google.com/open?id=1WZ3sZJHyikYQknH-pUejRUKebq2FNBcQ&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 6 (français)", url: "https://drive.google.com/open?id=18uRUge68iVnKsIODIsI2aKhCv70Uexye&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 7 (français)", url: "https://drive.google.com/open?id=1h6xuF5ZqMj3FXwwgbMkkr9xQjwuOzG_d&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 8 (français)", url: "https://drive.google.com/open?id=1LVv9h-2kfBiLgtNNTAq-73tlDp6en64h&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 9 (français)", url: "https://drive.google.com/open?id=1Cb5ODt1ZKRx9BpqB2_Y4PrI1r3OiAH8o&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 10 (français)", url: "https://drive.google.com/open?id=1QEWAAyYNB18O6IBtmeUIEl0Oun-4ZBPY&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 11 (français)", url: "https://drive.google.com/open?id=1X2Q0B_K4VXgiMLXP1LUWNAZrA_e1Vbvc&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 1 (anglais)", url: "https://drive.google.com/open?id=1_YdK_Jl5wgK6eglITPMi9ImuWnauCXRM&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 2 (anglais)", url: "https://drive.google.com/open?id=1Slplxo39dfJuf4kt0NYc8x8uNvrCHJDU&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 3 (anglais)", url: "https://drive.google.com/open?id=16TCTMsBb9iY6F3buTQ7c7_wVN6laSKie&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 4 (anglais)", url: "https://drive.google.com/open?id=1PuVi1VTojCp4QntDEeRn3BGQkfKWpVsI&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 5 (anglais)", url: "https://drive.google.com/open?id=1T3SUTRC3S7HEV1JROdu7YFsaTVDqxqxb&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 1 (anglais 2)", url: "https://drive.google.com/open?id=1zKnvUj-XgDRZNb38je-aFnzmxTHzGwpD&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 2 (anglais 2)", url: "https://drive.google.com/open?id=1eRzUqEwHRI4YVaVdoaQr7Fy-kCNWmU1w&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 3 (anglais 2)", url: "https://drive.google.com/open?id=1G6ABtavF8_l5SXEu6svu9ez0AXH5wVIo&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 4 (anglais 2)", url: "https://drive.google.com/open?id=1uqt34Ect2uv-5IKhznxPqJ1E75A_yn9l&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 5 (anglais 2)", url: "https://drive.google.com/open?id=1GRY9d7toBicB22IK3ZdiJr0UX9pnbyT9&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 6 (anglais 2)", url: "https://drive.google.com/open?id=1cfJt5tkZhJm5J3RBNyI1YHGkV9c0Q0yA&usp=drive_copy", type: "td", language: "english" },
                { title: "Examens (anglais)", url: "https://drive.google.com/open?id=1q3FgX4Od0Ppp-Myrf4CtBqXfx66HQRqH&usp=drive_copy", type: "exam", language: "english" },
                { title: "Livre", url: "https://drive.google.com/open?id=1q3FgX4Od0Ppp-Myrf4CtBqXfx66HQRqH&usp=drive_copy", type: "book", language: "english" }
              ]
            },
            {
              name: "Analyse 2",
              materials: [
                { title: "Cours 1 (anglais)", url: "https://drive.google.com/open?id=10p7YCf0ALx3YNqyhj1csgD17ermqE3jQ&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 2 (anglais)", url: "https://drive.google.com/open?id=1xUZHwXhZnOcIS8Kcguy8Q5n5hxdW6joJ&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 3 (anglais)", url: "https://drive.google.com/open?id=1eQuH1Nj0uYvbTmpJOrGYJE2Ovvzv-eV1&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 4 (anglais)", url: "https://drive.google.com/open?id=1wyQryt_V2U1tLC4TJXGTjVbrkQ6JrqPl&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 5 (anglais)", url: "https://drive.google.com/open?id=1fenv8ylaMFsbo_PwTBXgyjQGIQQDpW67&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 6 (anglais)", url: "https://drive.google.com/open?id=10cbdDa4a7jmlYsYXZdQ9CnLorkc3d9pS&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 1 (anglais 2)", url: "https://drive.google.com/open?id=1rVtSNp3AJu6jX_0ps_b9REi2cSNRogeR&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 2 (anglais 2)", url: "https://drive.google.com/open?id=1Qp1zG-v-HdZROb4GEuGczNgk_6Gvy-8C&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 3 (anglais 2)", url: "https://drive.google.com/open?id=1d_I7K56N_iKPTinbQEcNZTf-TZbyOgJr&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 4 (anglais 2)", url: "https://drive.google.com/open?id=15mfaW2DBC3IZXsItnpodGjkg2d1XoFST&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 5 (anglais 2)", url: "https://drive.google.com/open?id=1aHQ__W-uIYEOUCfuWQJC9-vg-6TT7YZv&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 6 (anglais 2)", url: "https://drive.google.com/open?id=1SRU9yVZ6fY_uA8W2lrNJeqnhNixEAXnV&usp=drive_copy", type: "course", language: "english" },
                { title: "TD et Exercices 1 (anglais)", url: "https://drive.google.com/open?id=1d29OOQ99gWGu7TpQyt-oFn3a9AL44CmK&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 2 (anglais)", url: "https://drive.google.com/open?id=1e0THhLc5N9XrGmiLrjDZqaCGP1ATgOmD&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 3 (anglais)", url: "https://drive.google.com/open?id=1aIk-GRv-GuAHW-DpRDDhj2110BeX4Fbf&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 4 (anglais)", url: "https://drive.google.com/open?id=18iBs9n8X5TCmej6QcWke8gNao7jOIVV2&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 5 (anglais)", url: "https://drive.google.com/open?id=1IgbXB14ZAoG6If2joDoOJhkAnFabavYA&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 1 (français)", url: "https://drive.google.com/open?id=13VE9TFfRY2EMNMValVlOusT6bf9wguLJ&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 2 (français)", url: "https://drive.google.com/open?id=1IuueeQpM4ojJ4c1Jsltxj_hRgDtQ64IO&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 3 (français)", url: "https://drive.google.com/open?id=1wiRBDigxb-Ajy-6yq73vkHlw3eCSjZ9Y&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 4 (français)", url: "https://drive.google.com/open?id=1z7v4WttSjG5onYxUbcbASEp5QsHh6Srm&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 5 (français)", url: "https://drive.google.com/open?id=1akAaI4kP7xtaV8qwpGdRWDva3a6N55ex&usp=drive_copy", type: "td", language: "french" },
                { title: "Examens (anglais)", url: "https://drive.google.com/open?id=1Km_yfY69vU2CgXbASSlBSb5y2Td7ZUxS&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 2 (anglais)", url: "https://drive.google.com/open?id=1Ken521cKYPDQBu6DsulDelbEhfa-xCk2&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 3 (anglais)", url: "https://drive.google.com/open?id=1K_pD-zVSxXj6N8hk-tsFhaNpTxwXkCmf&usp=drive_copy", type: "exam", language: "english" }
              ]
            },
            {
              name: "Chimie 2 (Thermodynamique)",
              materials: [
                { title: "TD Exercices Cours 1", url: "https://drive.google.com/open?id=12cNPpeZqxzc4jmuwQbgDvgcPEK_NJyhV&usp=drive_copy", type: "td", language: "english" },
                { title: "TD Exercices Cours 2", url: "https://drive.google.com/open?id=1vWfvEn7gvXkqsId6o-Cq3w_IrHqFYD9J&usp=drive_copy", type: "td", language: "english" },
                { title: "TD Exercices Cours 3", url: "https://drive.google.com/open?id=11fJS7eivtC9yX--ZcNSJ-f2IGQK1GEDG&usp=drive_copy", type: "td", language: "english" },
                { title: "TD Exercices Cours 4", url: "https://drive.google.com/open?id=1pJRFxOfBZTEdrHb3MAP8sjoOsnJaFuzR&usp=drive_copy", type: "td", language: "english" },
                { title: "TD Exercices Cours 5", url: "https://drive.google.com/open?id=15DSCyZn5u1q_H2kyXzdtTa8lsoUe9mU7&usp=drive_copy", type: "td", language: "english" },
                { title: "TD Exercices Cours 6", url: "https://drive.google.com/open?id=1rw0CN9hng6v7nrAqOlpK3CnZe26HYB7M&usp=drive_copy", type: "td", language: "english" },
                { title: "TD Exercices Cours 7", url: "https://drive.google.com/open?id=1P5CE7tXkpKRo2SHgNsXo-Vc-4OsqdqJn&usp=drive_copy", type: "td", language: "english" },
                { title: "TD Exercices Cours 8", url: "https://drive.google.com/open?id=1_BhucaV7oYah0RONfsVKBg8h7NcIegw-&usp=drive_copy", type: "td", language: "english" },
                { title: "TD Exercices Cours 9", url: "https://drive.google.com/open?id=1tDQPnPYKeOOou8o0dXsXy9-ZNOTlFlt_&usp=drive_copy", type: "td", language: "english" }
              ]
            },
            {
              name: "Physique 2",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=12cNPpeZqxzc4jmuwQbgDvgcPEK_NJyhV&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=1vWfvEn7gvXkqsId6o-Cq3w_IrHqFYD9J&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 3", url: "https://drive.google.com/open?id=11fJS7eivtC9yX--ZcNSJ-f2IGQK1GEDG&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 4", url: "https://drive.google.com/open?id=1pJRFxOfBZTEdrHb3MAP8sjoOsnJaFuzR&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 5", url: "https://drive.google.com/open?id=15DSCyZn5u1q_H2kyXzdtTa8lsoUe9mU7&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 6", url: "https://drive.google.com/open?id=1rw0CN9hng6v7nrAqOlpK3CnZe26HYB7M&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 7", url: "https://drive.google.com/open?id=1P5CE7tXkpKRo2SHgNsXo-Vc-4OsqdqJn&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 8", url: "https://drive.google.com/open?id=1_BhucaV7oYah0RONfsVKBg8h7NcIegw-&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 9", url: "https://drive.google.com/open?id=1tDQPnPYKeOOou8o0dXsXy9-ZNOTlFlt_&usp=drive_copy", type: "course", language: "english" },
                { title: "TD 1", url: "https://drive.google.com/open?id=1Kyw_ZVp-keEKP_92FrHEYII7pqGYPy_8&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 2", url: "https://drive.google.com/open?id=1w4O-IdAt1O2A4_i5q77N0E3pf3EqeqEL&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 3", url: "https://drive.google.com/open?id=14e7SuwNpzN8xXtylDjzy_bVkkR96tsWQ&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 4", url: "https://drive.google.com/open?id=1NkmQk33h-URzUJW8mLripsa8UDWNYO1j&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 5", url: "https://drive.google.com/open?id=1FOjfJN3yURN-g45JSd7y8tDy7i8RuLmO&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 6", url: "https://drive.google.com/open?id=1_jZvdATHdDkl9GuzYQVzreQpIYMBmBIn&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 7", url: "https://drive.google.com/open?id=1Vogfsu8Nj192iJP12ozdR0g7DoG-S9i_&usp=drive_copy", type: "td", language: "english" },
                { title: "Examen 1", url: "https://drive.google.com/open?id=1Kyw_ZVp-keEKP_92FrHEYII7pqGYPy_8&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 2", url: "https://drive.google.com/open?id=1w4O-IdAt1O2A4_i5q77N0E3pf3EqeqEL&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 3", url: "https://drive.google.com/open?id=14e7SuwNpzN8xXtylDjzy_bVkkR96tsWQ&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 4", url: "https://drive.google.com/open?id=1NkmQk33h-URzUJW8mLripsa8UDWNYO1j&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 5", url: "https://drive.google.com/open?id=1FOjfJN3yURN-g45JSd7y8tDy7i8RuLmO&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 6", url: "https://drive.google.com/open?id=1_jZvdATHdDkl9GuzYQVzreQpIYMBmBIn&usp=drive_copy", type: "exam", language: "english" },
                { title: "Examen 7", url: "https://drive.google.com/open?id=1Vogfsu8Nj192iJP12ozdR0g7DoG-S9i_&usp=drive_copy", type: "exam", language: "english" }
              ]
            },
            {
              name: "Informatique 2",
              materials: [
                { title: "Cours 1 (français)", url: "https://drive.google.com/open?id=1ZyRj2Ovt_Vwsp6Bb1qUPKAq31HwFrd-c&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2 (français)", url: "https://drive.google.com/open?id=1oNxc33UV7MWbdHrGrPQbC3NunmBc5Fta&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3 (français)", url: "https://drive.google.com/open?id=1VzE5XUL15GpWcuhiWwINA0H16oyO6HM8&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 4 (français)", url: "https://drive.google.com/open?id=1SE4KAN3nV7jOkwE-e03PoIyuzEgp9K5p&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 5 (français)", url: "https://drive.google.com/open?id=1hzGfS5GiCcMP5omof2lumsZxbnmpgFC0&usp=drive_copy", type: "course", language: "french" },
                { title: "Examens", url: "https://drive.google.com/open?id=1gNEL-JMTaLarqSTU2PW8oajhQfdHL7iD&usp=drive_copy", type: "exam", language: "french" }
              ]
            },
            {
              name: "Probabilités",
              materials: [
                { title: "Examens (français)", url: "https://drive.google.com/open?id=1Dc98vRYeBm9G2kVtVYdk4MifMLfHn391&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examens (anglais)", url: "https://drive.google.com/open?id=1fkjiVgjhXZkJsJ_lPLEQABnDbwJISr_E&usp=drive_copy", type: "exam", language: "english" },
                { title: "Cours 1 (anglais)", url: "https://drive.google.com/open?id=1s01zEkJPl7xsKzAvO2g08NcDISZN2s5O&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 2 (anglais)", url: "https://drive.google.com/open?id=15SN9e28VlJfV-fvZ0gqFlbIf1nUrnstM&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 3 (anglais)", url: "https://drive.google.com/open?id=13sul06rkJVb-O1xE1a-hrsmwqOILrjNz&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 4 (anglais)", url: "https://drive.google.com/open?id=1S7GYWNXMNFclk4oNtkluzysgP4h1SJGJ&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 5 (anglais)", url: "https://drive.google.com/open?id=1sFMxpePF4VYo8MNKMZAQ1XnuvYD3AD0E&usp=drive_copy", type: "course", language: "english" },
                { title: "TD 1 (anglais)", url: "https://drive.google.com/open?id=1Ryc1DIFRUhjpwTiiXfxpSTLL4QM2qi2U&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 2 (anglais)", url: "https://drive.google.com/open?id=1_nOzVCVqhDD2chSno1QQW4ezhUIFzxvX&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 3 (anglais)", url: "https://drive.google.com/open?id=1n_FNIUkztkV5xL4fLFyedE0JpWAK8gGJ&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 4 (anglais)", url: "https://drive.google.com/open?id=1NftmBaFQwoAPZOYMry-VpAMrjVgZQyaX&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 5 (anglais)", url: "https://drive.google.com/open?id=10Xp4iKt2ULFRw0v39y3sNfMlXpCjuMrP&usp=drive_copy", type: "td", language: "english" },
                { title: "TD 6 (anglais)", url: "https://drive.google.com/open?id=15a-2ovhCQPvL5CPGEn8RcWpfY7SNMyG4&usp=drive_copy", type: "td", language: "english" }
              ]
            },
            {
              name: "Économie 2",
              materials: [
                { title: "Cours", url: "https://drive.google.com/open?id=1-Az9s8vFVtFwFcyO6v2WEan1ydVqn3p1&usp=drive_copy", type: "course", language: "french" }
              ]
            },
            {
              name: "Human Engineering 2",
              materials: [
                { title: "Cours 1 (anglais)", url: "https://drive.google.com/open?id=16Gd3HqesZ_I2sJdYTkbQrFIvxfLpQoRY&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 2 (anglais)", url: "https://drive.google.com/open?id=1iGgkZiT6duawAlMWNiji8CvDgFiCzi4t&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 3 (anglais)", url: "https://drive.google.com/open?id=1JjM6YpJsMj3Y0Nj6fCF1zZY1dvLWQrGh&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 4 (anglais)", url: "https://drive.google.com/open?id=1HSLRlcPAydxKlizUhMmTsQIgrqYlA4VL&usp=drive_copy", type: "course", language: "english" },
                { title: "Cours 5 (anglais)", url: "https://drive.google.com/open?id=1bcMmooAXvnhKVGexBSrxNmjuOkx0ra8j&usp=drive_copy", type: "course", language: "english" },
                { title: "Examens", url: "https://drive.google.com/open?id=16Gd3HqesZ_I2sJdYTkbQrFIvxfLpQoRY&usp=drive_copy", type: "exam", language: "english" }
              ]
            }
          ]
        }
      ]
    },
    {
      name: "2ème Année",
      semesters: [
        {
          name: "Semestre 1",
          subjects: [
            {
              name: "MDF (Mécanique des Fluides)",
              materials: [
                { title: "Ultimate Pack", url: "https://drive.google.com/open?id=1hjhU5JTE1L-AYV3742jsQRZiuy5FMAv7&usp=drive_copy", type: "other", language: "french" },
                { title: "Examens corrigés Fluides réels", url: "https://drive.google.com/file/d/1PNVj3_5F8M8Of9BxJ1yKL7tpY-v-7hby/view?usp=drive_link", type: "exam", language: "french" },
                { title: "Livre MDF", url: "https://drive.google.com/open?id=1mWlJgU4lu_Dc7wfQ8xOBHuteuOiG49hP&usp=drive_copy", type: "book", language: "french" },
                { title: "Solutions TD MDF 1", url: "https://drive.google.com/file/d/1At0Ppy1bDEtms9u4QEysQTKv8hLkOFfo/view?usp=drive_link", type: "other", language: "french" },
                { title: "Solutions TD MDF 2", url: "https://drive.google.com/file/d/1FSHRos74qROqUsAtYxWMj7k7-2Wjptgo/view?usp=drive_link", type: "other", language: "french" },
                { title: "Solutions TD MDF 3", url: "https://drive.google.com/file/d/115eNH-_uSjqXFNbZ1KScVLFAL3n8ByTA/view?usp=drive_link", type: "other", language: "french" },
                { title: "Cours", url: "https://drive.google.com/open?id=1-URDGGAmzgYej1iTsV3C-hkejSCTNwk4&usp=drive_copy", type: "course", language: "french" },
                { title: "TD Autres", url: "https://drive.google.com/open?id=1Ayn9lXcz5mJlP5t7GNFJt-e3mzExKC3B&usp=drive_copy", type: "td", language: "french" },
                { title: "Cours Autres 1", url: "https://drive.google.com/open?id=1-B4BOR7Qv2u3gSylvULoeVrK9LvfHixB&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Autres 2", url: "https://drive.google.com/open?id=1_b2AwNSFvbG_M7TFwtMjNk-r2DtLHmTE&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Autres 3", url: "https://drive.google.com/open?id=1a5NhXubvVKUiBp2EJ_lBIswakN_kl8jg&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Autres 4", url: "https://drive.google.com/open?id=130g81tadsgmkSBGk5ZD6CTKaiWfiOfrl&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Autres 5", url: "https://drive.google.com/open?id=1stSY1FLjoq57LZvtEZ7yAlfVvvb4IsWN&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Autres 6", url: "https://drive.google.com/open?id=1aCMwa3dpfV43GhG7SowAJ2nu3I5XmXf8&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Autres 7", url: "https://drive.google.com/open?id=1g1-RBEDWsoIMNFnmHLeIgGZCFVEt3mYM&usp=drive_copy", type: "course", language: "french" }
              ]
            },
            {
              name: "MDC (Mécanique Des Continus)",
              materials: [
                { title: "Pack", url: "https://drive.google.com/drive/folders/1aeP9kt2GbSM1GYwUdgUY7FVv2pCXfQVB?usp=drive_link", type: "other", language: "french" },
                { title: "Résumé", url: "https://drive.google.com/open?id=10rEq_2M-HwowjoDU0cuAoemX4DTvGiHP&usp=drive_copy", type: "resume", language: "french" }
              ]
            },
            {
              name: "MDS (Mécanique Des Solides)",
              materials: [
                { title: "Pack", url: "https://drive.google.com/drive/folders/1h6i8pwBI2atdcKjcM5EZdT8LcYL8sJe4?usp=drive_link", type: "other", language: "french" },
                { title: "Cours 1", url: "https://drive.google.com/open?id=16xDDog8A5UmQ8QhbXRwQE1naz0Arm269&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=14qv0WqpIui9W-h9eFvKFXUGkYHc0WcMl&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3", url: "https://drive.google.com/open?id=144qa_I8Ned6H2C_i33tbovzH06UvC3wM&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 4", url: "https://drive.google.com/open?id=15a-GIWOQX66BR9Vn-bqrJR0mEFSQydWG&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 5", url: "https://drive.google.com/open?id=1o9-wdhkMxLcXfpQSMVD-8-i062Jxjz1l&usp=drive_copy", type: "course", language: "french" },
                { title: "TD 1", url: "https://drive.google.com/open?id=1qwKLkSZ4zCHih1vT6-7U9IJbZwz0DMZ7&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 2", url: "https://drive.google.com/open?id=1ZDRwXOvMG03wDNAHX9TCxKF8Q-Y1QL_b&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 3", url: "https://drive.google.com/open?id=1S3zI4WHmky-ZwpTBW4dlzGx26X52BSer&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 4", url: "https://drive.google.com/open?id=1-sQohKpP0PzYmyFvPLMHjzaX7TGEjVxV&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 5", url: "https://drive.google.com/open?id=1FK9ePIIXHrHUf4lajJIX3gTrun2WXV9h&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 6", url: "https://drive.google.com/open?id=1MTHPjXr2bIMNOILwNmCwKdOlvOAHaE3a&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 7", url: "https://drive.google.com/open?id=1ZhpAwTpUjhSeYTsKo9LEu3buDEuW1KPW&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 8", url: "https://drive.google.com/open?id=1RxN914_fiheZ0vhT9SyGQzGZ0LFh2Qvf&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 9", url: "https://drive.google.com/open?id=1XeGSamuivPXpPd6DUFYkUHsFbE2q3lGl&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 10", url: "https://drive.google.com/open?id=1GLvkCQFtdopsRlnataC5EvK-1qzuXold&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 11", url: "https://drive.google.com/open?id=1pdq6w7Q3mNjzzLYcpmbo9AXvceN8YOkC&usp=drive_copy", type: "td", language: "french" },
                { title: "Interrogation et Préparation Examen 1", url: "https://drive.google.com/open?id=1-7lpIaehBx5H_OCWfVbAc3oq5wSiF8VL&usp=drive_copy", type: "exam", language: "french" },
                { title: "Interrogation et Préparation Examen 2", url: "https://drive.google.com/open?id=1OvAFNDhjb9KjSHQwZvo9ABVwBm_DUDVg&usp=drive_copy", type: "exam", language: "french" },
                { title: "Interrogation et Préparation Examen 3", url: "https://drive.google.com/open?id=1AtW_sIvpx8QD4WWZGysBvlj4cvDfqXb9&usp=drive_copy", type: "exam", language: "french" },
                { title: "Interrogation et Préparation Examen 4", url: "https://drive.google.com/open?id=1VjATeggF8eAFrgk8naEvQaKvQeujwijI&usp=drive_copy", type: "exam", language: "french" },
                { title: "Interrogation et Préparation Examen 5", url: "https://drive.google.com/open?id=1kYOoKuuqpSoyMdyAox_NPefRJIVfZf_K&usp=drive_copy", type: "exam", language: "french" },
                { title: "Interrogation et Préparation Examen 6", url: "https://drive.google.com/open?id=1WUUFmAqg_6oN2re-u2Ckk8jtUSDEq_Cp&usp=drive_copy", type: "exam", language: "french" }
              ]
            },
            {
              name: "MMC (Mécanique Des Milieux Continus)",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=1ZS3VZaDzUJwBEDeb7hxcpr9Phd9wMOnl&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=1e5NG4kn_7BdrKzWgqKzYW2qG40gNVmu-&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3", url: "https://drive.google.com/open?id=1zkud6eOC5vT4UgZBDrq_JtgSx5X23r4B&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 4", url: "https://drive.google.com/open?id=1vGDVZyg0Sz-79e7W1liRRqOj2ta9toCS&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 5", url: "https://drive.google.com/open?id=1UIobPqVUJxO1ZHS1vV0AuXxJLmIvTqti&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 6", url: "https://drive.google.com/open?id=1CDcpcPobqymaJ5gULJaHAuKRsOJ-Tg3F&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 7", url: "https://drive.google.com/open?id=10ke7k356OnkGHSI1L2Tswnsj5gY0zjG-&usp=drive_copy", type: "course", language: "french" },
                { title: "Cahier", url: "https://drive.google.com/open?id=11S60FMkHd853ZCn_b6Y3MIJYavv6n29G&usp=drive_copy", type: "other", language: "french" },
                { title: "TD 1", url: "https://drive.google.com/open?id=1lV0eFqUxfIe8T5TTSgV5C8vD7yxzIV6j&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 2", url: "https://drive.google.com/open?id=1OyQBCg2AheaVK-em5VHelrVY5aaq9fzv&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 3", url: "https://drive.google.com/open?id=1NNpBOWwm-6bk0Eur4gDw5Z_yppiQt_wo&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 4", url: "https://drive.google.com/open?id=1qTsU3ywQXrPct8HoMhKY3xfD1GjcLdgG&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 5", url: "https://drive.google.com/open?id=1iFhx4-Bm6-VzAihhFJOnq_HFZ8WkgD1v&usp=drive_copy", type: "td", language: "french" },
                { title: "Examen", url: "https://drive.google.com/open?id=16-X9xpLNpmKC5rBFkUORvxoyFuFiOZks&usp=drive_copy", type: "exam", language: "french" }
              ]
            },
            {
              name: "RDM (Résistance Des Matériaux)",
              materials: [
                { title: "Ultimate Pack", url: "https://drive.google.com/drive/folders/1-K1dMIhi0g6ta8suoXSEX51vZywZsPJQ?usp=drive_link", type: "other", language: "french" },
                { title: "Chapitre 1", url: "https://drive.google.com/open?id=1u1_xadIEHoxN9PKbt7rGP00YKZF-y7Qh&usp=drive_copy", type: "course", language: "french" },
                { title: "Chapitre 2", url: "https://drive.google.com/open?id=1vTKEOXQ0uFabQIsrDMlEXeSZTOj0ClU5&usp=drive_copy", type: "course", language: "french" },
                { title: "Chapitre 3", url: "https://drive.google.com/open?id=1PsQlnBYeIshWxZownyXUcrqH0MBa5_IO&usp=drive_copy", type: "course", language: "french" },
                { title: "Chapitre 4", url: "https://drive.google.com/open?id=1RZ_DkbMhwFFEKLx2kopHGsVUy7mE9byH&usp=drive_copy", type: "course", language: "french" }
              ]
            },
            {
              name: "Topographie",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=1UsdvcZCnSWrY7qwgdP2tVXysN_HnzCrw&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=1jzEgHIJUWedyt8nFHJ6s-9bcExAWtWfF&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3", url: "https://drive.google.com/open?id=1mnxkJjRHaV9H7x3LqsBU5zPg4Vg1mBfL&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 4", url: "https://drive.google.com/open?id=1UfFVTA1Xrz25m3D0JyD6d9umTlbdi68i&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 5", url: "https://drive.google.com/open?id=10yohbihtmK9oeuNGeK9JpGCM5t5G_VpA&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 6", url: "https://drive.google.com/open?id=1tAEx7grP-FmqgYb96Ym33X9ZSy7W6bPV&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 7", url: "https://drive.google.com/open?id=1J6vQOAPxvc6iMs7lcJPTWTLeBXgXtqKU&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 8", url: "https://drive.google.com/open?id=1k6UDR70M9DPJ0UGsrL4Vu46vWzPFRUzq&usp=drive_copy", type: "course", language: "french" },
                { title: "Examens", url: "https://drive.google.com/open?id=1jEzXSPMLK7xC90_3T6JB--M7BqNsUk6h&usp=drive_copy", type: "exam", language: "french" }
              ]
            },
            {
              name: "Géologie",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=1Oni7x9JSOF2wLCZXWPdaapD70k3wXmWV&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=1GcCDQUPPGzdvNaAqtZqlG75g_Y4vLxuJ&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3", url: "https://drive.google.com/open?id=1a_Txfm2YYwi6SWc1Hc_tiPYP3q3x67fW&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 4", url: "https://drive.google.com/open?id=1wKoHZKKeC0GiEIvt2Ul44V-oqtYrGsUK&usp=drive_copy", type: "course", language: "french" },
                { title: "Géol Barrages et géologie BTS", url: "https://drive.google.com/file/d/1p-4zfz_5hRw3dRIqhxZBgeGpxjvebVia/view?usp=drive_link", type: "course", language: "french" },
                { title: "TP 1 Géophys sism refraction", url: "https://drive.google.com/file/d/1gEHpqQhaMrroNaQHAS570qQKgZUpKQAB/view?usp=drive_link", type: "other", language: "french" },
                { title: "Cours Géologie détaillé 1", url: "https://drive.google.com/open?id=1q_Gwint6HBUIuCvWps6DTaxXKnb1ljB9&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 2", url: "https://drive.google.com/open?id=17Ai-57GW8ocI-yvGuh7nHcs0Gv3aYi3p&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 3", url: "https://drive.google.com/open?id=1f2tnym3nHQ4NY_0vrhIiBYnd4VZvv5FL&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 4", url: "https://drive.google.com/open?id=1P8Qg2RWCPb7cbULS5GXgICmVeSTWyw-2&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 5", url: "https://drive.google.com/open?id=1oFcRPhPiwRQLQSx8VA0v4l3JJyym_hVx&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 6", url: "https://drive.google.com/open?id=1eSHP-zWomnozbKKSBu7T1oOIEkW5PM2l&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 7", url: "https://drive.google.com/open?id=1UPZPdNGOOwoJVhqpHtJQTkuxy4rlk_wF&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 8", url: "https://drive.google.com/open?id=1UKzU16kbqzaBVNsV9ChXO1tX7iFwx-oF&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 9", url: "https://drive.google.com/open?id=1R7TbwhQe7e4LhEYfA5vY58uXV8wKLCSl&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 10", url: "https://drive.google.com/open?id=1AhW9cCOePG7bi_pEkX06UjOu-ItxS0tY&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 11", url: "https://drive.google.com/open?id=1Qzwr0YiCiJi5LErxIttvZljSLlF1Fkp9&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 12", url: "https://drive.google.com/open?id=1FJyrfm07DU32O6BVeXFMyUbIJ2j9lSwz&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 13", url: "https://drive.google.com/open?id=1JQcbFykPZROyc5AIdGEtya5Lq89pOXgs&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 14", url: "https://drive.google.com/open?id=1hhMJJwgWylVnakgIiPvD_b8ilDeDPYmZ&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours Géologie détaillé 15", url: "https://drive.google.com/open?id=1OwkG0DEYatF4FNf-29STJhxYhCu0853r&usp=drive_copy", type: "course", language: "french" },
                { title: "TP 3", url: "https://drive.google.com/open?id=10hcI0zJFOknsmFGobWnQMHAgTLA5MOXo&usp=drive_copy", type: "other", language: "french" }
              ]
            },
            {
              name: "ANANUM (Analyse Numérique)",
              materials: [
                { title: "Examen 1", url: "https://drive.google.com/open?id=1lCBvB9GmI6mEzmrSSLv6c9rFx2434MAQ&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 2", url: "https://drive.google.com/open?id=1nkRVxkpq0SeqJ_vWxUYuRy94XzZL0Cne&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 3", url: "https://drive.google.com/open?id=1vRN9FbUu9-376Hg3fjFqP8Mp7G7YcsSv&usp=drive_copy", type: "exam", language: "french" },
                { title: "TD 1", url: "https://drive.google.com/open?id=1WEu8wXqf29XgMihFAYdcYSJVF5SyQDXT&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 2", url: "https://drive.google.com/open?id=1hf8RQnD4jhaGE9gNeQSZJwN8v44bNmwC&usp=drive_copy", type: "td", language: "french" },
                { title: "TD 3", url: "https://drive.google.com/open?id=1RBQaN44btHm-kln_RW2XCDnHWbuI2W1N&usp=drive_copy", type: "td", language: "french" },
                { title: "Interrogation 1", url: "https://drive.google.com/open?id=1MZTFTOsGFQsu-BRmQO2mpCNhrKVo5peh&usp=drive_copy", type: "exam", language: "french" },
                { title: "Interrogation 2", url: "https://drive.google.com/open?id=1umjIlCQX6vgiM0aNBEBs0aX7E9Q-j_yr&usp=drive_copy", type: "exam", language: "french" },
                { title: "Résumé 1", url: "https://drive.google.com/open?id=1xGFsI7wRwVEjMuBBFZWXKqtZkerRuYBQ&usp=drive_copy", type: "resume", language: "french" },
                { title: "Résumé 2", url: "https://drive.google.com/open?id=1xxqyhC0OefLQrNz4vTdFq5gPWfVDmhpf&usp=drive_copy", type: "resume", language: "french" },
                { title: "Résumé 3", url: "https://drive.google.com/open?id=1kxul3fRjnVp7LKPiQhNHtIqq8o0i1a_K&usp=drive_copy", type: "resume", language: "french" },
                { title: "Résumé 4", url: "https://drive.google.com/open?id=1s8Luen-eoL3-gMW97YeudXEgWBi0xmmR&usp=drive_copy", type: "resume", language: "french" },
                { title: "Résumé 5", url: "https://drive.google.com/open?id=1gQ3owrOTv8WsQ2xhc2zsjfxi_67PZYZV&usp=drive_copy", type: "resume", language: "french" },
                { title: "Solutions TD ANANUM", url: "https://drive.google.com/drive/folders/1kWd6t-qP2jK0Tg9mA0SMMps2n3lrpQGU?usp=drive_link", type: "other", language: "french" },
                { title: "Cours", url: "https://drive.google.com/open?id=1-i9X2lXB0u3ryM23K-s7FKuAlzo7K5RD&usp=drive_copy", type: "course", language: "french" }
              ]
            },
            {
              name: "Hydrologie Appliquée",
              materials: [
                { title: "Ultimate Pack", url: "https://drive.google.com/open?id=1jAPHwB3CCwvhT7ZTBayIesnzhkucMWXt&usp=drive_copy", type: "other", language: "french" }
              ]
            }
          ]
        },
        {
          name: "Semestre 2",
          subjects: [
            {
              name: "ROUTE",
              materials: [
                { title: "Cours", url: "https://drive.google.com/open?id=1ouDWbs9l-0eM0nbVIBRlMvsmXEKFHb8J&usp=drive_copy", type: "course", language: "french" },
                { title: "Ultimate Pack", url: "https://drive.google.com/open?id=10eZY0dkojDUx8kmIQ7TmkbboJtZbB4zZ&usp=drive_copy", type: "other", language: "french" },
                { title: "Exercice", url: "https://drive.google.com/open?id=1FJgbMgqkbvPqUwq7AhELCmvYDb5lhJiM&usp=drive_copy", type: "exercise", language: "french" },
                { title: "ROUTE KARA", url: "https://drive.google.com/drive/folders/15iOzwtbknb-PR884oeg5ICgj-AkDK-KW?usp=drive_link", type: "other", language: "french" },
                { title: "Cours Route Words", url: "https://drive.google.com/drive/folders/1-wfNt-EIanoJKb2WZgd5evFoP4DygZ8r?usp=drive_link", type: "course", language: "french" },
                { title: "Routes: matériaux, durabilité des chaussées", url: "https://drive.google.com/drive/folders/1-wfNt-EIanoJKb2WZgd5evFoP4DygZ8r?usp=drive_link", type: "course", language: "french" }
              ]
            },
            {
              name: "RDM 2",
              materials: [
                { title: "Coming Soon", url: "#", type: "other", language: "french" }
              ]
            },
            {
              name: "MMC 2",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=1OiBgCWDrNt2tWyAAH2yIQ6ppCKzXdiSh&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=1pvBKpSjs3I9FywgEy1RxEhUVGxdd9KeQ&usp=drive_copy", type: "course", language: "french" }
              ]
            },
            {
              name: "MDS 3",
              materials: [
                { title: "Ultimate Pack", url: "https://drive.google.com/open?id=1zuNjlqYLMcS2nqz42Jx5RuMQcPENxIDP&usp=drive_copy", type: "other", language: "french" },
                { title: "Résumé", url: "https://drive.google.com/open?id=1opJc0TvBGOOS96pN-NtOM_Iqx_sK3UeG&usp=drive_copy", type: "resume", language: "french" },
                { title: "TD", url: "https://drive.google.com/open?id=105uPJzZodqtU3mspqBeznrgdqcz1F87b&usp=drive_copy", type: "td", language: "french" }
              ]
            },
            {
              name: "MDC 2",
              materials: [
                { title: "Coming Soon", url: "#", type: "other", language: "french" }
              ]
            },
            {
              name: "Hydraulique Appliquée",
              materials: [
                { title: "Coming Soon", url: "#", type: "other", language: "french" }
              ]
            },
            {
              name: "Structure",
              materials: [
                { title: "Ultimate Pack", url: "https://drive.google.com/open?id=1mmEd-O17HuQi1uSv7rOTkSl0GSopbj09&usp=drive_copy", type: "other", language: "french" },
                { title: "Résumé", url: "https://drive.google.com/open?id=1ppn8EL59NSSlX8KUlknfTBdHmtmqVNiv&usp=drive_copy", type: "resume", language: "french" },
                { title: "Cours 1", url: "https://drive.google.com/open?id=1BTjm9PT3x59pmgJk_tucdezU3fNGROR6&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=1VqXRX03I6S95-7adCTstaBMW3uTA014_&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3", url: "https://drive.google.com/open?id=1DN6sD5ZYU8Sjhnaokh2JUlVCYSh2VSKG&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 4", url: "https://drive.google.com/open?id=1EZlwWPrZgxMM7HxNf7g3tjXuGQOP-omu&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 5", url: "https://drive.google.com/open?id=1JBM0DjKnIwAgPIxUIQaQkozSIp6q5MgB&usp=drive_copy", type: "course", language: "french" }
              ]
            }
          ]
        }
      ]
    }
  ]
};

// Engineering Cycle Data
export const engineeringCycle: Program = {
  name: "Cycle d'Ingénierie",
  years: [
    {
      name: "1ère Année",
      semesters: [
        {
          name: "Semestre 1",
          subjects: [
            {
              name: "Analyse 3",
              materials: [
                { title: "Cours 1 (français)", url: "https://drive.google.com/open?id=1VTDFmbaIt9Air9ZpxLNgZoJs696xNIVW&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2 (français)", url: "https://drive.google.com/open?id=1VR6Lqvcqjwo182hgTzATrZX2UXEL1Sp4&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3 (français)", url: "https://drive.google.com/open?id=18RtAe1pj-fpOq8KDVFVgeflDPlPOjDaT&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 4 (français)", url: "https://drive.google.com/open?id=1Apk9yFSdblaBgC-6hZJVTWLUkdPkW9q0&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 5 (français)", url: "https://drive.google.com/open?id=1N98Nq8phQ-1GlGnUqjeOi8wYfDq4J083&usp=drive_copy", type: "course", language: "french" },
                { title: "Résumé 1", url: "https://drive.google.com/open?id=1Xq1brWQdHaEUQvk2CjhG85u9e-2aFanB&usp=drive_copy", type: "resume", language: "french" },
                { title: "Résumé 2", url: "https://drive.google.com/open?id=1IKriQwUHEQFWdB9Lzj7Q_6Xfy3-k5oMk&usp=drive_copy", type: "resume", language: "french" },
                { title: "Résumé 3", url: "https://drive.google.com/open?id=1mgBSSTmEICarSi8xDEpsjUC6SmJhme0I&usp=drive_copy", type: "resume", language: "french" },
                { title: "Résumé 4", url: "https://drive.google.com/open?id=1DFZys7vxMmtV37u8vwyu4ea5Atdg9ctF&usp=drive_copy", type: "resume", language: "french" },
                { title: "Examen 1", url: "https://drive.google.com/open?id=1y8sbpCmDJgeNiSxqvKPNMPH0RNs9QS-u&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 2", url: "https://drive.google.com/open?id=13T0R37wm-t2ecHLsLv8L917lii98uw2I&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 3", url: "https://drive.google.com/open?id=1g4DjRqfujtlbOUVXX8c3VJAkMS1QsdEa&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 4", url: "https://drive.google.com/open?id=1PPl3L4ei5uPmAMa8FjUDP1UJATLnHv_f&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 5", url: "https://drive.google.com/open?id=1UmsJnems9dxvtY0UpN9RY0-LKoDFegHE&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 6", url: "https://drive.google.com/open?id=1asNpPxLfh555p4p-e751rPzJWM8DCJCk&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 7", url: "https://drive.google.com/open?id=1-Od3fQVXRZsg7fD5u7kRzDKOLDkTQRtB&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen 8", url: "https://drive.google.com/open?id=1Y_8iNLO1Qe12LaiF5p2TWJOSi9pQPIl5&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen ENSTP 1", url: "https://drive.google.com/open?id=1obVYlhzgQ7WnhkXlQ-mC2RdVnsU9tO3m&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen ENSTP 2", url: "https://drive.google.com/open?id=1oxajJ6Axosco9OQZf4GYIM5xJLj3P3yg&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen ENSTP 3", url: "https://drive.google.com/open?id=1KmjC0wmJRjWUsxD-b0fJcxXS8tESGbVn&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen ENSTP 4", url: "https://drive.google.com/open?id=1thiVZuSJiIGJaejdKR5cpZGHINY4C2cV&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen ENSTP 5", url: "https://drive.google.com/open?id=1sHxjhpCv2yCxkhvbAE04E7ejRLVSAJF6&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen ENSTP 6", url: "https://drive.google.com/open?id=1C7gSohPapLOOn6oyKb9cVn5gGgvNe-Af&usp=drive_copy", type: "exam", language: "french" },
                { title: "TD ENSTP 1", url: "https://drive.google.com/open?id=1BIuyoDlQzx71WnVvY5sfum_ppIf3JaqW&usp=drive_copy", type: "td", language: "french" },
                { title: "TD ENSTP 2", url: "https://drive.google.com/open?id=15BjPt3_ZraNKCa3MHbq4aF4TUDLGbYMr&usp=drive_copy", type: "td", language: "french" },
                { title: "TD ENSTP 3", url: "https://drive.google.com/open?id=1HcO1ombUT5cojUJnf9qCOoogDV5hVSCP&usp=drive_copy", type: "td", language: "french" },
                { title: "TD ENSTP 4", url: "https://drive.google.com/open?id=1uQz7Yp_kqoGBAMm4KpcS4VfDSNWhyuTq&usp=drive_copy", type: "td", language: "french" },
                { title: "TD ENSTP 5", url: "https://drive.google.com/open?id=1QEaf6zPhIdmRYYFCmOdsdhKbS6THRwZx&usp=drive_copy", type: "td", language: "french" },
                { title: "TD ENSTP 6", url: "https://drive.google.com/open?id=1Hd6RJ7iwd8cyWhot4bWtMW8amPKv0nG_&usp=drive_copy", type: "td", language: "french" },
                { title: "English Classroom", url: "https://classroom.google.com/u/9/c/NTU1NDgzNzY2NDAx", type: "other", language: "english" }
              ]
            },
            {
              name: "Physique 3",
              materials: [
                { title: "Cours", url: "https://drive.google.com/open?id=16tPHgnNAwqEVHru4pr8xThvoSOjDl-0U&usp=drive_copy", type: "course", language: "english" },
                { title: "Autres cours", url: "https://drive.google.com/open?id=1_gpkkh-StVlQfFbcIECOJZbmmRQ-J8D_&usp=drive_copy", type: "course", language: "english" },
                { title: "Tous les cours Mr Berroudji", url: "https://drive.google.com/open?id=1fQXpR-bjd2ejnSCwj7V9VH0vdokuz5J-&usp=drive_copy", type: "course", language: "french" },
                { title: "Résumé", url: "https://drive.google.com/open?id=1DeTog5eQjOaKP9QmPaNlK0JJ1mJm5BgQ&usp=drive_copy", type: "resume", language: "french" },
                { title: "DM Mr Berroudji", url: "https://drive.google.com/open?id=1HGPrhiirnT-kH1hwYAlEfvEvZEI_ZyE7&usp=drive_copy", type: "other", language: "french" },
                { title: "DS Mr Berroudji", url: "https://drive.google.com/open?id=1eDBGZiYVXPuIvHVPwiwdl9DUhmnglwqy&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examen Mr Berroudji", url: "https://drive.google.com/open?id=1g7DdDmdLewlZQkH3gVW3_WW0dMjIKppU&usp=drive_copy", type: "exam", language: "french" },
                { title: "TD Mr Berroudji 1", url: "https://drive.google.com/open?id=1XvXrDarSTXPL5tQhin-iyOJ7V0BhetNy&usp=drive_copy", type: "td", language: "french" },
                { title: "TD Mr Berroudji 2", url: "https://drive.google.com/open?id=1w2FXeKKzjoNTTw1Hbv9zobfazMJR3rRV&usp=drive_copy", type: "td", language: "french" },
                { title: "TD Mr Berroudji 3", url: "https://drive.google.com/open?id=1KY5yacEAPF9VMzcOz-O90OXrt_3J1BRa&usp=drive_copy", type: "td", language: "french" },
                { title: "TD Mr Berroudji 4", url: "https://drive.google.com/open?id=1ZC0LPo_0o2O3peq-Ip-c74K8deUv4suY&usp=drive_copy", type: "td", language: "french" }
              ]
            },
            {
              name: "Chimie 3",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=1kKJhrDMN65UV7Y8MACvQrqy02_FuBYmi&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=106Ed9Dgy3CLh1IkaliLebhVSiwZbVicu&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 3", url: "https://drive.google.com/open?id=1oAM077ElfvN3fVX1mLGGFK92y11ZKFxT&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 4", url: "https://drive.google.com/open?id=1RqeBcfyvjYgoNF9sV1SFOlM0kDhYIMLn&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 5", url: "https://drive.google.com/open?id=1L5MLypMOsf9RJbHUcnFPpVxlNbaanVo0&usp=drive_copy", type: "course", language: "french" },
                { title: "Examens", url: "https://drive.google.com/open?id=1hJ0DU0zYlTUoi49rKpkt2WLdo8fwptHm&usp=drive_copy", type: "exam", language: "french" },
                { title: "TD", url: "https://drive.google.com/open?id=1A-d1tzQnDToXWmi1l-pr49DgafwLTBSG&usp=drive_copy", type: "td", language: "french" }
              ]
            },
            {
              name: "ANANUM 1",
              materials: [
                { title: "Cours", url: "https://drive.google.com/open?id=1qb9MQqTLgqKDSoWwMPBzP3EddnmYy5E-&usp=drive_copy", type: "course", language: "french" },
                { title: "Examens", url: "https://drive.google.com/open?id=1OWN4JH3G2qsdairfrK-a4_SBAnqJkyXC&usp=drive_copy", type: "exam", language: "french" },
                { title: "TD Mr Hammadi", url: "https://drive.google.com/open?id=1AjlrkSrg5l_ksmXSA1uMjimLGZaUAjbu&usp=drive_copy", type: "td", language: "french" }
              ]
            },
            {
              name: "Électricité 1",
              materials: [
                { title: "TD", url: "https://drive.google.com/open?id=1J0PXbDJPUQnbP5c57W_QVuaNPhTasGKe&usp=drive_copy", type: "td", language: "french" },
                { title: "Cours", url: "https://drive.google.com/open?id=1hI8-QyNla3-BeZbTQZ37mYBqhYTgmHlH&usp=drive_copy", type: "course", language: "french" },
                { title: "Examens", url: "https://drive.google.com/open?id=19KscZFyujU6B-oMamn0toVTvPEQ6yBS1&usp=drive_copy", type: "exam", language: "french" }
              ]
            },
            {
              name: "Informatique 3",
              materials: [
                { title: "Cours", url: "https://drive.google.com/open?id=1P5cUlD_qaJvhVcMX5XPCIRgcMenuv401&usp=drive_copy", type: "course", language: "french" },
                { title: "TD", url: "https://drive.google.com/open?id=1S58vxhwH6uNCrWf4LJjd8K0pJ2PIqP4T&usp=drive_copy", type: "td", language: "french" },
                { title: "Examen", url: "https://drive.google.com/open?id=1Dj08cYdJQpo41HBlhi4BBYGs5U1TT6k9&usp=drive_copy", type: "exam", language: "french" }
              ]
            },
            {
              name: "MDF (Mécanique des Fluides)",
              materials: [
                { title: "Cours Mr Berroudji", url: "https://drive.google.com/open?id=101nmjOOG8x9jbIQUujIekWGyQ6C3-MYa&usp=drive_copy", type: "course", language: "french" },
                { title: "DS Mr Berroudji", url: "https://drive.google.com/open?id=1yNcgcli9YC5OnjzmcDSptycWnLNnEgMn&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examens", url: "https://drive.google.com/open?id=1Qz-S-Qu83ESpZNjdsuS4iD4bKlxGQ8l9&usp=drive_copy", type: "exam", language: "french" },
                { title: "TD", url: "https://drive.google.com/open?id=1vt-OpT5Z7lvoQaybA2J69q68hN-qesxH&usp=drive_copy", type: "td", language: "french" }
              ]
            },
            {
              name: "Mécanique Rationnelle",
              materials: [
                { title: "Cours", url: "https://drive.google.com/open?id=1o31PIjvaPzeJ9RPqA0kYfZjiG89Z0uAt&usp=drive_copy", type: "course", language: "french" },
                { title: "TD", url: "https://drive.google.com/open?id=1BM6gl1nVZ4XucgVT8OY2JTnvLsIFnua3&usp=drive_copy", type: "td", language: "french" },
                { title: "Examens", url: "https://drive.google.com/open?id=1SP_PKqiM5KIGIrNSsWWVu_nRnaSgwIay&usp=drive_copy", type: "exam", language: "french" }
              ]
            },
            {
              name: "Engineering",
              materials: [
                { title: "Classroom Link", url: "https://classroom.google.com/u/9/c/NzE5ODI3NzI4OTI4", type: "other", language: "english" }
              ]
            }
          ]
        },
        {
          name: "Semestre 2",
          subjects: [
            {
              name: "Analyse 4",
              materials: [
                { title: "Cours", url: "https://drive.google.com/open?id=1FkLk_h1OMrbSMbf5buIrCH7j4Ifcggef&usp=drive_copy", type: "course", language: "french" },
                { title: "TD", url: "https://drive.google.com/open?id=1dHVTEueSPDYHY8ExOwpJrY4q0Y7MfGFG&usp=drive_copy", type: "td", language: "french" },
                { title: "Examen", url: "https://drive.google.com/open?id=1g36075hCYANxvdsod-K4O-zB7pbmsSr6&usp=drive_copy", type: "exam", language: "french" }
              ]
            },
            {
              name: "ANANUM 2",
              materials: [
                { title: "Cours", url: "https://drive.google.com/open?id=1HMAEx5mqQyAHP0G6hGH0vaMxnTs3t6_A&usp=drive_copy", type: "course", language: "french" },
                { title: "Examen", url: "https://drive.google.com/open?id=1xTDmTtOvZrP6gCnMQ8zIzEPf_-esI3sb&usp=drive_copy", type: "exam", language: "french" },
                { title: "TD", url: "https://drive.google.com/open?id=1p8u6mcy278AkcyFVD3nTnjLh7IvwT24L&usp=drive_copy", type: "td", language: "french" }
              ]
            },
            {
              name: "Physique 4",
              materials: [
                { title: "Cours Mr Berroudji", url: "https://drive.google.com/open?id=1w4GcuybMbP9kR4MLBaMawr8tlZw4mm2i&usp=drive_copy", type: "course", language: "french" },
                { title: "DS Mr Berroudji", url: "https://drive.google.com/open?id=1WV5cZiFSRgS5Un8lqLgLN9dygahMM90v&usp=drive_copy", type: "exam", language: "french" },
                { title: "Examens Mr Berroudji", url: "https://drive.google.com/open?id=1VsbWBJ3OEXEUwbgTgHVBjhR6tx4xGNwF&usp=drive_copy", type: "exam", language: "french" },
                { title: "TD Mr Berroudji", url: "https://drive.google.com/open?id=1s3A70nHjEulqApAXge3jDO5-4focxxCl&usp=drive_copy", type: "td", language: "french" }
              ]
            },
            {
              name: "Chimie 4",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=1UilMG_f0E_9SFrb-WGD8BMTp78TIlbGX&usp=drive_copy", type: "course", language: "french" },
                { title: "Examens", url: "https://drive.google.com/open?id=1yZz7sOC7NMZElJ47b2usrSZ0yC-ULB-3&usp=drive_copy", type: "exam", language: "french" },
                { title: "TD", url: "https://drive.google.com/open?id=1EHqm9eAyd4yXBbbtqgQdukN-CKJJqI1u&usp=drive_copy", type: "td", language: "french" }
              ]
            },
            {
              name: "Informatique 4",
              materials: [
                { title: "Cours", url: "https://drive.google.com/open?id=1oc-FDLmRY-Lvq1FQLTp4T5-3mhVaIbTH&usp=drive_copy", type: "course", language: "french" },
                { title: "TD", url: "https://drive.google.com/open?id=1veu_MLKI5cT-4uXQszsEQKMwAzK_R4lR&usp=drive_copy", type: "td", language: "french" }
              ]
            },
            {
              name: "Électronique",
              materials: [
                { title: "Cours", url: "https://drive.google.com/open?id=1lhxweJalP2PNcW4alRTd3WsiYjxIzG2K&usp=drive_copy", type: "course", language: "french" },
                { title: "Résumés", url: "https://drive.google.com/open?id=1J67jdMvxzv_stKlkN03toxxACWDdmRtM&usp=drive_copy", type: "resume", language: "french" },
                { title: "TD", url: "https://drive.google.com/open?id=1B2EPereIQvoOF4v1Pp0VcQrx9ct7SGPm&usp=drive_copy", type: "td", language: "french" }
              ]
            },
            {
              name: "Résistance Des Matériaux",
              materials: [
                { title: "Cours 1", url: "https://drive.google.com/open?id=1DMz-ceaOB6fFEo7E05aFTDLUwLpJeeyh&usp=drive_copy", type: "course", language: "french" },
                { title: "Cours 2", url: "https://drive.google.com/open?id=1Fu_sNpn7XqBUUEs9nSDJeZJ5cuEG6P0d&usp=drive_copy", type: "course", language: "french" },
                { title: "Examens", url: "https://drive.google.com/open?id=1GKnnFP37pQFqRdDh8Vwx7_WRR4_rdInF&usp=drive_copy", type: "exam", language: "french" },
                { title: "TDs", url: "https://drive.google.com/open?id=18Y5Pu3w-J7ljF-V9hkKpD7z0_S1f_frM&usp=drive_copy", type: "td", language: "french" }
              ]
            },
            {
              name: "Mécanique Rationnelle 2",
              materials: [
                { title: "Livre Kaddi", url: "https://drive.google.com/open?id=1sBwoJDR23jvoe33LEt-7cW1dIcYMQvFp&usp=drive_copy", type: "book", language: "french" },
                { title: "TD et Solutions", url: "https://drive.google.com/open?id=1hW7Oo0Fvizp4rRluOWtR-9WPuzyi9m_k&usp=drive_copy", type: "td", language: "french" },
                { title: "Cours", url: "https://drive.google.com/open?id=1xE1lMMt8raXd5uZKiO1c6oieaOC_RSBP&usp=drive_copy", type: "course", language: "french" },
                { title: "Interrogation et Examens", url: "https://drive.google.com/open?id=1ekDJuWyHCj7lFaYP8hueQOYwME3M4av_&usp=drive_copy", type: "exam", language: "french" }
              ]
            },
            {
              name: "Engineering 2",
              materials: [
                { title: "Resources 1", url: "https://t.me/enstp2cp/1986", type: "other", language: "french" },
                { title: "Resources 2", url: "https://t.me/enstp2cp/1983", type: "other", language: "french" },
                { title: "Resources 3", url: "https://t.me/enstp2cp/1915", type: "other", language: "french" }
              ]
            },
            {
              name: "Dessin Technique 2",
              materials: [
                { title: "Excellent Résumé", url: "https://t.me/enstp2cp/1927", type: "resume", language: "french" }
              ]
            }
          ]
        }
      ]
    }
  ]
};

// Additional Resources
export const additionalResources = {
  concours: [
    { title: "Concours Resources 1", url: "https://drive.google.com/open?id=14jplCiz04HIE7HS72_0BocEHcpexnq5H&usp=drive_copy", type: "other", language: "french" },
    { title: "Concours Resources 2", url: "https://drive.google.com/open?id=1eMt9cVLBToXIwu1xuEa1iQzENt887KuC&usp=drive_copy", type: "other", language: "french" },
    { title: "Concours Resources 3", url: "https://drive.google.com/open?id=1vJbWfM40_IHpkSvRZ1p7J2yP59mtO14n&usp=drive_copy", type: "other", language: "french" },
    { title: "Concours Resources 4", url: "https://drive.google.com/open?id=1_cBNNrv8VWn9vUtVV4I691es_xxeIdM-&usp=drive_copy", type: "other", language: "french" },
    { title: "Concours Resources 5", url: "https://drive.google.com/open?id=1QlNF9HlVIfyPmtMgxrbWiMPHwao5Vz08&usp=drive_copy", type: "other", language: "french" },
    { title: "Concours Resources 6", url: "https://drive.google.com/open?id=1pVvExKfn9dxspLTSIvVV1rKJciD0Chdv&usp=drive_copy", type: "other", language: "french" },
    { title: "Concours Resources 7", url: "https://drive.google.com/open?id=1xL8BcimnH3bRSqxHmwfpAfNMtLB4DpD5&usp=drive_copy", type: "other", language: "french" }
  ],
  driveLinks: [
    { title: "Drive Folder 1", url: "https://drive.google.com/drive/folders/185bOgBgeHrcLN9cq0_5DwRrV8odCXrLr", type: "other", language: "french" },
    { title: "Drive Folder 2", url: "https://drive.google.com/drive/folders/1dvQlnp_IxGrMpZrq2q0L1lAaIuWtvw1h", type: "other", language: "french" },
    { title: "Drive Folder 3", url: "https://drive.google.com/drive/folders/1dvx-lEa5cdgDNLhie9mfho0MKJFdaHcY", type: "other", language: "french" },
    { title: "Drive Folder 4", url: "https://drive.google.com/drive/folders/1fKaDNvX6HvahLClgzTYEzvsKYV4w8BNP", type: "other", language: "french" }
  ],
  tps: {
    physique: [
      { title: "TP Physique 1", url: "https://drive.google.com/open?id=1o0S-hhx0ry6gdTeGvvdDJne-bRJeA1Uz&usp=drive_copy", type: "other", language: "french" },
      { title: "TP Physique 2", url: "https://drive.google.com/open?id=1VV7V-BV0xclkpPhTZPUS0jPhTPfBiHzg&usp=drive_copy", type: "other", language: "french" },
      { title: "TP Physique 3", url: "https://drive.google.com/open?id=1Rp6rLlDJ0vjze0BP8HoMJEQ_g8ehirdQ&usp=drive_copy", type: "other", language: "french" },
      { title: "TP Physique 4", url: "https://drive.google.com/open?id=11U4VivDzavmYx-yLYMSU__gVtodvc7FC&usp=drive_copy", type: "other", language: "french" },
      { title: "TP Physique 5", url: "https://drive.google.com/open?id=1oHvTnFzNfoRDi0Z0i4-EemoqQxTQV0ws&usp=drive_copy", type: "other", language: "french" },
      { title: "TP Physique 6", url: "https://drive.google.com/open?id=1jnMNb955vzG9KhgIHbavJ99dpYHZe6Bv&usp=drive_copy", type: "other", language: "french" },
      { title: "TP Physique 7", url: "https://drive.google.com/open?id=1O05JAcLg1QevHzY4AVeoGpcltfA3Oe4k&usp=drive_copy", type: "other", language: "french" },
      { title: "TP Physique 8", url: "https://drive.google.com/open?id=1c-d2IP9FWSIa9NLNKZ4x86mo5yxzDhZJ&usp=drive_copy", type: "other", language: "french" }
    ],
    chimie: [
      { title: "TP Chimie 1", url: "https://drive.google.com/open?id=1rvtFiP4aV_5h8IMZmFLLfrL5Maaq4P3V&usp=drive_copy", type: "other", language: "french" },
      { title: "TP Chimie 2", url: "https://drive.google.com/open?id=1XIrN0aZq-h-vUX_taZSLA-FTcoePQphn&usp=drive_copy", type: "other", language: "french" }
    ]
  }
};